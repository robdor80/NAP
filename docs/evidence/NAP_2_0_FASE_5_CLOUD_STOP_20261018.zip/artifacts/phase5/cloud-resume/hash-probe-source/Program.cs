using System.Diagnostics;
using System.Security.Cryptography;
using System.Text.Json;
using NAP.Core;
var path = "/workspace/.nap-tools/hash-probe/synthetic.bin";
using (var file = new FileStream(path, FileMode.Create, FileAccess.Write)) file.SetLength(64L * 1024 * 1024);
var measurements = new List<object>(); string? expected = null;
foreach (var buffered in new[] { false, true, false, true })
{
    using var source = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
    var before = Io(); var timer = Stopwatch.StartNew();
    var hash = buffered ? new Sha256Hasher().Compute(source).Hex : Convert.ToHexString(SHA256.HashData(source)).ToLowerInvariant();
    timer.Stop(); var after = Io(); expected ??= hash;
    if (hash != expected || source.Position != source.Length) throw new Exception("Whole-byte hash mismatch");
    measurements.Add(new { buffered, bytes = source.Position, seconds = timer.Elapsed.TotalSeconds,
        readCalls = after["syscr"] - before["syscr"], readChars = after["rchar"] - before["rchar"], hash });
}
Console.WriteLine(JsonSerializer.Serialize(measurements, new JsonSerializerOptions { WriteIndented = true }));
File.Delete(path);
static Dictionary<string, long> Io() => File.ReadAllLines("/proc/self/io").Select(s => s.Split(':', 2))
    .ToDictionary(s => s[0], s => long.Parse(s[1].Trim()));
