"""Collect only image-update evidence; exclude the issued license and private build log."""
from pathlib import Path
import datetime, hashlib, json, re, sys, zipfile
import xml.etree.ElementTree as ET

# Never include license field values in exception output, including malformed dates.
sys.excepthook = lambda kind, value, trace: print(f'Evidence collection failed ({kind.__name__}); private details withheld.', file=sys.stderr)

root = Path(__file__).resolve().parent
repo = root.parents[2]
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
digest = lambda data: hashlib.sha256(data).hexdigest()
trx = root / 'imagesharp-320-directed.trx'
tree = ET.parse(trx)
results = tree.findall('t:Results/t:UnitTestResult', ns)
allowed = {'ImageNormalizationTests', 'ImageNormalizationSafetyTests',
           'PortraitPngToWebpConverterTests', 'ScenePngToWebpConverterTests',
           'PortraitWebpOutputValidatorTests', 'SceneWebpOutputValidatorTests', 'ProductionThumbnailTests'}
families = {}
for result in results:
    family = result.get('testName').split('.')[2]
    assert family in allowed, family
    assert result.get('outcome') == 'Passed', result.get('testName')
    families[family] = families.get(family, 0) + 1
assert len(results) == 220 and set(families) == allowed
packages = json.loads((root / 'packages-installed.json').read_text(encoding='utf-8-sig'))
resolved = []
for project in packages['projects']:
    for framework in project.get('frameworks', []):
        for kind in ('topLevelPackages', 'transitivePackages'):
            for package in framework.get(kind, []):
                if package['id'] == 'SixLabors.ImageSharp':
                    assert package['resolvedVersion'] == '3.2.0'
                    resolved.append(dict(project=Path(project['path']).name, kind=kind, version='3.2.0'))
assert len(resolved) == 8
license_text = (repo / 'sixlabors.lic').read_text(encoding='utf-8-sig').strip()
fields = dict(part.split('=', 1) for part in license_text.split(';') if '=' in part)
assert fields['Kind'] == 'Community' and fields['Key'].startswith('Assembly:')
expiry_text = re.sub(r'(\.\d{6})\d+(?=Z|[+-])', r'\1', fields['ExpiryDateUtc'])
expiry = datetime.datetime.fromisoformat(expiry_text.replace('Z', '+00:00'))
assert (expiry.year, expiry.month) == (2028, 1) and expiry > datetime.datetime.now(datetime.timezone.utc)
package_dll = Path.home() / '.nuget/packages/sixlabors.imagesharp/3.2.0/lib/net6.0/SixLabors.ImageSharp.dll'
test_dll = repo / 'tests/NAP.Tests/bin/Release/net8.0/SixLabors.ImageSharp.dll'
assert digest(package_dll.read_bytes()) == digest(test_dll.read_bytes())
report = dict(recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              sourceParentCommit='9b485a9686b194ea127b3a10c6bf65c94630a24b',
              changedProject=dict(file='src/NAP.Core/NAP.Core.csproj', sha256=digest((repo / 'src/NAP.Core/NAP.Core.csproj').read_bytes())),
              imageSharp=dict(version='3.2.0', informationalVersion='3.2.0+baa37cd19077b2a2a0c5667535111cf31d48c019',
                              executedDllSha256=digest(test_dll.read_bytes()), executedDllMatchesResolvedPackage=True,
                              projectResolutions=resolved, nugetAdvisoriesStillReported=5, auditSuppressionsAdded=False,
                              publisherBackportConfirmation='https://sixlabors.com/posts/security-support-and-license-enforcement/'),
              license=dict(community=True, assemblyScoped=True, assemblyValidatedByOfficialReleaseBuild='NAP.Core',
                           notExpired=True, expiryMatchesJanuary2028=True, ignoredByGit=True,
                           published=False, uploadedAsGithubSecret=False, copiedIntoBuildOutput=False),
              releaseBuild=dict(command='dotnet build NAP.sln -c Release --verbosity minimal', exitCode=0,
                                compileErrors=0, licenseValidationErrors=0, rawLogExcludedAsPrivate=True),
              tests=dict(file=trx.relative_to(repo).as_posix(), sha256=digest(trx.read_bytes()),
                         executed=220, passed=220, failed=0, omitted=0, families=families),
              zipVolumeTestsExecuted=False, generalRegressionExecuted=False, ciExecuted=False,
              productionActivated=False, realNimroelChanged=False, cutoverExecuted=False)
(root / 'release-build-summary.json').write_text(json.dumps(report['releaseBuild'], indent=2)+'\n', encoding='utf-8')
(root / 'image-update-summary.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
names = ['imagesharp-320-directed.trx', 'image-tests.log', 'image-filter.txt', 'packages-installed.json',
         'packages-vulnerable.json', 'release-build-summary.json', 'image-update-summary.json', 'collect_image_evidence.py']
files = [root / name for name in names]
private_fragments = [license_text, fields['Key'], fields.get('Id', '')]
private_fragments = [part.encode('utf-8') for part in private_fragments if len(part) > 16]
for file in files:
    assert not any(fragment in file.read_bytes() for fragment in private_fragments), 'Private license data detected'
inventory = [dict(file=p.name, bytes=p.stat().st_size, sha256=digest(p.read_bytes())) for p in files]
archive = repo / 'docs/evidence/NAP_2_0_IMAGESHARP_320_20261020.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as bundle:
    for file in files:
        bundle.write(file, file.name)
    bundle.writestr('evidence-inventory.json', json.dumps(inventory, indent=2))
with zipfile.ZipFile(archive) as bundle:
    assert len(bundle.namelist()) == len(files) + 1
    for entry in inventory:
        assert digest(bundle.read(entry['file'])) == entry['sha256']
report['archive'] = dict(file=archive.relative_to(repo).as_posix(), sha256=digest(archive.read_bytes()),
                         dataEntries=len(files), allEntryHashesVerified=True, licenseAndPrivateLogExcluded=True)
output = json.dumps(report, ensure_ascii=False, indent=2)+'\n'
assert not any(fragment in output.encode('utf-8') for fragment in private_fragments)
(repo / 'docs/NAP_2_0_FASE_5_IMAGESHARP_320_EVIDENCE.json').write_text(output, encoding='utf-8')
print(json.dumps(dict(tests=report['tests'], archive=report['archive']), indent=2))
