"""Read-only TRX summarizer and bounded evidence archive; never launches tests."""
from pathlib import Path
import datetime, hashlib, json, zipfile
import xml.etree.ElementTree as ET

repo = Path(__file__).resolve().parents[3]
root = Path(__file__).resolve().parent
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
sha = lambda data: hashlib.sha256(data).hexdigest()
families = ['AutomationProcessRecoveryTests', 'AutomationAuditStageTests',
            'AutomationAcceptanceTests', 'AutomationDesktopTests', 'AutomationWpfTests',
            'VisualExplorerWindowsSmokeTests', 'PreparationStorageDiagnosticsTests',
            'LedgerValidationProofTests', 'ExecutionCoordinationProcessTests',
            'ImageNormalizationTests', 'ImageNormalizationSafetyTests',
            'PortraitPngToWebpConverterTests', 'ScenePngToWebpConverterTests']
prior = json.loads((repo / 'docs/NAP_2_0_FASE_5_REGRESSION_COMPARISON.json').read_text(encoding='utf-8-sig'))
runs = []
for path in sorted(root.rglob('*.trx')):
    tree = ET.parse(path)
    results = tree.findall('t:Results/t:UnitTestResult', ns)
    names = {r.get('testName'): r.get('outcome') for r in results}
    forbidden = [name for name in names if 'SeparateHostCompletesUniqueMastersWithFairnessAndBoundedResources' in name
                 or 'MonitorAdmitsVolumeWithBoundedPendingAndDurableDeduplication' in name]
    assert not forbidden, forbidden
    outcomes = {key: sum(r.get('outcome') == key for r in results) for key in sorted(set(names.values()))}
    run = dict(file=path.relative_to(repo).as_posix(), sha256=sha(path.read_bytes()),
               runOutcome=tree.find('t:ResultSummary', ns).get('outcome'),
               rawCounters=tree.find('t:ResultSummary/t:Counters', ns).attrib,
               actualResultOutcomes=outcomes, prohibitedVolumeResults=forbidden,
               failedTests=[r.get('testName') for r in results if r.get('outcome') == 'Failed'],
               omittedTests=[r.get('testName') for r in results if r.get('outcome') == 'NotExecuted'])
    run['families'] = {f: {k: sum(f'NAP.Tests.{f}.' in r.get('testName', '') and r.get('outcome') == k
                                        for r in results) for k in outcomes}
                       for f in families if any(f'NAP.Tests.{f}.' in n for n in names)}
    if path.name in ('windows-regression.trx', 'windows-functional.trx', 'linux-regression.trx'):
        run['original18'] = [dict(test=p['test'], previousClassification=p['previousClassification'],
                                 currentOutcome=names.get(p['test'], 'Missing')) for p in prior['comparisons']]
    runs.append(run)

assert any(r['file'].endswith('/ci-windows/windows-regression/windows-regression.trx')
           or '/ci-windows/' in r['file'] and r['file'].endswith('/windows-regression.trx') for r in runs), 'Windows CI evidence missing'
assert any(r['file'].endswith('/windows-functional.trx') for r in runs), 'Local regression missing'
report = dict(recordedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              repository='robdor80/NAP', branch='codex/nap-2-fase-5-automation-host',
              testedSourceCommit='1bef7ecd1c1234ba0f4dbd014d7eef4bef93589a',
              ciRun=39474539947, cancelledPriorRun=39468522189,
              scope=dict(normalZipVolume='1-20', historical100Sufficient=True,
                         historical1000Outcome='Failed', thousandGateWithdrawn=True,
                         newVolumeRunsAuthorized=False, newVolumeRunsExecuted=False),
              imageSharp=dict(resolved='3.1.12', direct='NAP.Core', advisoriesRemaining=5,
                              candidate='3.2.0', isolatedReleaseBuildExitCode=1,
                              updateBlocked='Valid Six Labors build license not configured',
                              productDependencyChanged=False),
              storageUnavailable=dict(historicalCauseEstablished=False, loadReproducerRun=False,
                                      existingFailClosedTreatmentAndDiagnosticsRetained=True),
              localIpcTimeout=dict(test='DurableInhibitionsAndRestartAuthorizationCannotBeBypassed(mode: "cancel")',
                                   query='QueuePage', unchangedDeadlineSeconds=20,
                                   originalGeneralRunOutcome='Failed', subsequentDirectedModesPassed=4,
                                   causeEstablished=False, corrected=False),
              main=dict(sha='cd7532f011eea8a72e89848234b259f1f5293e15', protected=False,
                        effectiveRules=[], settingsChanged=False),
              productionActivated=False, cutoverExecuted=False, realNimroelModified=False,
              windowsAccountsOrPermissionsChanged=False, runs=runs)
(root / 'functional-results-summary.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

excluded = {'imagesharp-advisories.json', 'imagesharp-release-3.2.0.json',
            'imagesharp-3.2.0-readme.md', 'draft-pr-body.md'}
files = [p for p in root.rglob('*') if p.is_file() and p.name not in excluded
         and 'imagesharp-build-probe' not in p.parts
         and p.suffix.lower() in ('.json', '.log', '.trx', '.py', '.png')]
assert not any('launch' in p.name.lower() or p.suffix in ('.lic', '.key') for p in files)
inventory = [dict(file=p.relative_to(root).as_posix(), bytes=p.stat().st_size, sha256=sha(p.read_bytes())) for p in sorted(files)]
archive = repo / 'docs/evidence/NAP_2_0_FASE_5_FINAL_REVIEW_20261020.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as bundle:
    for entry in inventory:
        bundle.write(root / entry['file'], entry['file'])
    bundle.writestr('evidence-inventory.json', json.dumps(inventory, ensure_ascii=False, indent=2))
with zipfile.ZipFile(archive) as bundle:
    assert len(bundle.namelist()) == len(inventory) + 1
    for entry in inventory:
        assert sha(bundle.read(entry['file'])) == entry['sha256'], entry['file']
report['archive'] = dict(file=archive.relative_to(repo).as_posix(), sha256=sha(archive.read_bytes()),
                         bytes=archive.stat().st_size, dataEntries=len(inventory), allEntryHashesVerified=True)
(repo / 'docs/NAP_2_0_FASE_5_FINAL_REVIEW_EVIDENCE.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(archive=report['archive'], runs=[dict(file=r['file'], outcomes=r['actualResultOutcomes']) for r in runs]), indent=2))
